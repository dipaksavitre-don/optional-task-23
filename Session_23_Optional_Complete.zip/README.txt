SESSION 23 AIML - OPTIONAL TASK

Files:
- app.py
- diabetes_model.pkl
- breast_cancer_logistic.pkl
- breast_cancer_knn.pkl
- breast_cancer_nb.pkl
- scaler.pkl
- columns.pkl
- requirements.txt

RUN:
1. Open terminal in this folder.
2. Install packages:
   pip install -r requirements.txt
3. Run:
   streamlit run app.py

The application opens in a browser.


import streamlit as st
import pandas as pd
import numpy as np
import joblib
import matplotlib.pyplot as plt

from sklearn.datasets import load_breast_cancer, load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report, r2_score

st.set_page_config(page_title="Session 23 AIML", page_icon="🤖", layout="wide")

# Load saved models
diabetes_model = joblib.load("diabetes_model.pkl")
logistic_model = joblib.load("breast_cancer_logistic.pkl")
knn_model = joblib.load("breast_cancer_knn.pkl")
nb_model = joblib.load("breast_cancer_nb.pkl")
scaler = joblib.load("scaler.pkl")
columns = joblib.load("columns.pkl")

# Prepare datasets for evaluation/comparison
diabetes = load_diabetes()
X_d = pd.DataFrame(diabetes.data, columns=diabetes.feature_names)
y_d = pd.Series(diabetes.target, name="target")

cancer = load_breast_cancer()
X_c = pd.DataFrame(cancer.data, columns=cancer.feature_names)
y_c = pd.Series(cancer.target, name="target")

X_train, X_test, y_train, y_test = train_test_split(
    X_c, y_c, test_size=0.2, random_state=42, stratify=y_c
)
X_train_scaled = scaler.transform(X_train)
X_test_scaled = scaler.transform(X_test)

st.title("🤖 Session 23 (AIML) - Complete Model Frontend")
st.caption("Optional Task: Frontend for all models built in Session 23")

menu = st.sidebar.radio(
    "📌 Select Section",
    [
        "🏠 Home",
        "Q1 - Linear Regression",
        "Q2 - Logistic Regression",
        "Q3 - KNN",
        "Q4 - Naive Bayes",
        "Q5 - Algorithm Comparison"
    ]
)

def cancer_inputs(prefix):
    values = []
    cols = st.columns(3)
    for i, col in enumerate(columns):
        with cols[i % 3]:
            values.append(st.number_input(
                col,
                value=0.0,
                format="%.6f",
                key=f"{prefix}_{i}"
            ))
    return values

if menu == "🏠 Home":
    st.header("Welcome to Session 23 AIML")
    st.write("This application provides a frontend for all models in the assignment.")
    st.markdown("""
    ### Models
    - 📈 Linear Regression
    - ❤️ Logistic Regression
    - 🔍 K-Nearest Neighbors (KNN)
    - 🧠 Naive Bayes
    - 📊 Algorithm Comparison
    """)
    st.info("Select a section from the left sidebar.")

elif menu == "Q1 - Linear Regression":
    st.header("Q1. Linear Regression")
    st.write("Diabetes dataset - continuous target prediction.")

    values = []
    cols = st.columns(2)
    for i, col in enumerate(X_d.columns):
        with cols[i % 2]:
            values.append(st.number_input(
                col, value=0.0, format="%.6f", key=f"diabetes_{i}"
            ))

    if st.button("🔮 Predict Target", type="primary"):
        prediction = diabetes_model.predict([values])[0]
        st.success(f"Predicted Target Value: {prediction:.2f}")

    y_pred_d = diabetes_model.predict(X_d)
    st.metric("Model R² (full dataset reference)", f"{r2_score(y_d, y_pred_d):.4f}")

elif menu == "Q2 - Logistic Regression":
    st.header("Q2. Logistic Regression")
    st.write("Breast Cancer dataset - binary classification.")

    values = cancer_inputs("logistic")

    if st.button("🔮 Predict", type="primary"):
        data = pd.DataFrame([values], columns=columns)
        data_scaled = scaler.transform(data)
        prediction = logistic_model.predict(data_scaled)[0]
        probability = logistic_model.predict_proba(data_scaled)[0].max()

        if prediction == 0:
            st.error(f"Prediction: Malignant | Confidence: {probability:.2%}")
        else:
            st.success(f"Prediction: Benign | Confidence: {probability:.2%}")

    pred = logistic_model.predict(X_test_scaled)
    cm = confusion_matrix(y_test, pred)
    c1, c2 = st.columns(2)
    c1.metric("Accuracy", f"{accuracy_score(y_test, pred):.4f}")
    c2.metric("F1 Score", f"{f1_score(y_test, pred):.4f}")
    st.subheader("Confusion Matrix")
    st.dataframe(pd.DataFrame(cm, index=["Actual 0", "Actual 1"], columns=["Predicted 0", "Predicted 1"]))

elif menu == "Q3 - KNN":
    st.header("Q3. K-Nearest Neighbors")
    st.write("Try different K values: 3, 5, and 7.")

    values = cancer_inputs("knn")
    k = st.selectbox("Select K", [3, 5, 7], index=1)

    if st.button("🔮 Predict", type="primary"):
        data = pd.DataFrame([values], columns=columns)
        data_scaled = scaler.transform(data)
        model = KNeighborsClassifier(n_neighbors=k)
        model.fit(X_train_scaled, y_train)
        prediction = model.predict(data_scaled)[0]

        if prediction == 0:
            st.error("Prediction: Malignant")
        else:
            st.success("Prediction: Benign")

    rows = []
    for kval in [3, 5, 7]:
        model = KNeighborsClassifier(n_neighbors=kval)
        model.fit(X_train_scaled, y_train)
        pred = model.predict(X_test_scaled)
        rows.append([kval, accuracy_score(y_test, pred)])

    knn_results = pd.DataFrame(rows, columns=["K Value", "Accuracy"])
    st.subheader("K Value Accuracy Comparison")
    st.dataframe(knn_results, hide_index=True)

    fig, ax = plt.subplots()
    ax.plot(knn_results["K Value"], knn_results["Accuracy"], marker="o")
    ax.set_xlabel("K Value")
    ax.set_ylabel("Accuracy")
    ax.set_title("KNN Accuracy for Different K Values")
    ax.grid(True)
    st.pyplot(fig)

    best = knn_results.loc[knn_results["Accuracy"].idxmax()]
    st.success(f"Best K: {int(best['K Value'])} | Accuracy: {best['Accuracy']:.4f}")

elif menu == "Q4 - Naive Bayes":
    st.header("Q4. Naive Bayes")
    st.write("Breast Cancer dataset - Gaussian Naive Bayes classification.")

    values = cancer_inputs("nb")

    if st.button("🔮 Predict", type="primary"):
        data = pd.DataFrame([values], columns=columns)
        data_scaled = scaler.transform(data)
        prediction = nb_model.predict(data_scaled)[0]

        if prediction == 0:
            st.error("Prediction: Malignant")
        else:
            st.success("Prediction: Benign")

    pred = nb_model.predict(X_test_scaled)
    st.subheader("Classification Report")
    report = classification_report(y_test, pred, output_dict=True)
    st.dataframe(pd.DataFrame(report).transpose())

    st.subheader("Confusion Matrix")
    cm = confusion_matrix(y_test, pred)
    st.dataframe(pd.DataFrame(cm, index=["Actual 0", "Actual 1"], columns=["Predicted 0", "Predicted 1"]))

elif menu == "Q5 - Algorithm Comparison":
    st.header("Q5. Algorithm Comparison")
    st.write("Comparison of Logistic Regression, KNN and Naive Bayes on the same dataset.")

    models = {
        "Logistic Regression": logistic_model,
        "KNN": knn_model,
        "Naive Bayes": nb_model
    }

    results = []
    for name, model in models.items():
        pred = model.predict(X_test_scaled)
        results.append([
            name,
            accuracy_score(y_test, pred),
            precision_score(y_test, pred),
            recall_score(y_test, pred),
            f1_score(y_test, pred)
        ])

    comparison = pd.DataFrame(
        results,
        columns=["Algorithm", "Accuracy", "Precision", "Recall", "F1 Score"]
    )

    st.subheader("Comparison Table")
    st.dataframe(
        comparison.style.format({
            "Accuracy": "{:.4f}",
            "Precision": "{:.4f}",
            "Recall": "{:.4f}",
            "F1 Score": "{:.4f}"
        }),
        hide_index=True
    )

    st.subheader("Performance Graph")
    metric_cols = ["Accuracy", "Precision", "Recall", "F1 Score"]
    chart_data = comparison.set_index("Algorithm")[metric_cols]
    st.bar_chart(chart_data)

    best = comparison.loc[comparison["Accuracy"].idxmax()]
    st.success(
        f"Best Performing Algorithm: {best['Algorithm']} "
        f"(Accuracy = {best['Accuracy']:.4f})"
    )
    st.write("Reason: The algorithm with the highest accuracy performed best on this dataset.")
